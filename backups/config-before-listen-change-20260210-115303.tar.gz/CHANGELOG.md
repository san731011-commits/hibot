# Changelog

## 2026-02-10
- Add backup + tar scripts
- Add .allowlist and recovery README
- Initial healthcheck commit and tags
