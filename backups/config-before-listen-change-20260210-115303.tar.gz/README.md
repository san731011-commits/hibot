# hibot

Repository for OpenClaw hibot backups and configs.

Includes:
- backup scripts (git_backup.sh, tar_backup.sh)
- allowlist
- recovery instructions

